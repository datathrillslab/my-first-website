import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import FlameOverlay from './components/FlameOverlay';

gsap.registerPlugin(ScrollTrigger);

const panels = [
  { id: 1, src: '/images/pic_01.png' },
  { id: 2, src: '/images/pic_02.png' },
  { id: 3, src: '/images/pic_03.png' },
  { id: 4, src: '/images/pic_04.png' },
];

export default function App() {
  const mainRef = useRef<HTMLDivElement>(null);
  const intensityRef = useRef(0);
  const lastPanelRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const panelEls = gsap.utils.toArray<HTMLElement>('.comic-panel');
      lastPanelRef.current = panelEls[panelEls.length - 1] || null;

      // Reveal each panel and keep it revealed
      panelEls.forEach((panel) => {
        gsap.fromTo(
          panel,
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: panel,
              start: 'top 85%',
              toggleActions: 'play none none none',
            },
          }
        );
      });

      // Pin panel 4
      const lastPanel = panelEls[panelEls.length - 1];
      if (lastPanel) {
        ScrollTrigger.create({
          trigger: lastPanel,
          start: 'top top',
          pin: true,
          pinSpacing: false,
        });
      }
    }, mainRef);

    // Simple scroll listener for flame — only at the end
    const handleScroll = () => {
      const lastPanel = lastPanelRef.current;
      if (!lastPanel) return;
      
      const rect = lastPanel.getBoundingClientRect();
      const vh = window.innerHeight;
      
      // Panel 4 is at end when it's near/past the top of viewport
      // Flame only appears in the final 15% of the scroll
      const progress = 1 - (rect.top / vh);
      const flameProgress = Math.max(0, Math.min((progress - 0.85) / 0.15, 1));
      intensityRef.current = flameProgress;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll(); // initial check

    return () => {
      ctx.revert();
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div ref={mainRef} className="relative bg-[#080808]">
      {panels.map((panel) => (
        <section
          key={panel.id}
          className="comic-panel relative w-full min-h-screen flex items-center justify-center py-16"
        >
          <div className="relative max-w-full max-h-[80vh] shadow-[0_0_80px_rgba(0,0,0,0.9)]">
            <img
              src={panel.src}
              alt={`Panel ${panel.id}`}
              className="max-w-full max-h-[80vh] object-contain block"
            />
          </div>
        </section>
      ))}

      <FlameOverlay intensityRef={intensityRef} />
    </div>
  );
}
