import { useEffect, useRef, useState } from 'react';
import type { MutableRefObject } from 'react';

interface FlameOverlayProps {
  intensityRef: MutableRefObject<number>;
}

const IMG_W = 593;
const IMG_H = 640;
const OFFSET_X = 65;  // px right from center (70px left from original 135)
const OFFSET_Y = 40;  // px up from center

export default function FlameOverlay({ intensityRef }: FlameOverlayProps) {
  const glowRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const rafRef = useRef(0);

  useEffect(() => {
    const updatePosition = () => {
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const maxH = vh * 0.8;
      const scale = Math.min(vw / IMG_W, maxH / IMG_H);
      const renderedW = IMG_W * scale;
      const renderedH = IMG_H * scale;
      const left = (vw - renderedW) / 2;
      const top = (vh - renderedH) / 2;

      const matchX = left + (IMG_W / 2 + OFFSET_X) * scale;
      const matchY = top + (IMG_H / 2 - OFFSET_Y) * scale;

      setPosition({ x: matchX, y: matchY });
    };

    updatePosition();
    window.addEventListener('resize', updatePosition);

    // Smooth intensity animation loop
    let smooth = 0;
    const loop = () => {
      const target = intensityRef.current;
      smooth += (target - smooth) * 0.08;
      if (smooth < 0.005) smooth = 0;

      const el = glowRef.current;
      if (el) {
        el.style.opacity = String(smooth);
      }

      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', updatePosition);
    };
  }, [intensityRef]);

  return (
    <div
      ref={glowRef}
      style={{
        position: 'fixed',
        left: position.x,
        top: position.y,
        width: '0px',
        height: '0px',
        pointerEvents: 'none',
        zIndex: 100,
        opacity: 0,
      }}
    >
      {/* Layer 1: Bright white-hot core */}
      <div
        style={{
          position: 'absolute',
          left: '-30px',
          top: '-40px',
          width: '60px',
          height: '80px',
          borderRadius: '50%',
          background: 'radial-gradient(ellipse 50% 60% at 50% 55%, rgba(255,255,245,0.85) 0%, rgba(255,235,160,0.5) 45%, transparent 75%)',
          animation: 'flicker 0.8s ease-in-out infinite alternate',
        }}
      />
      {/* Layer 2: Yellow inner glow */}
      <div
        style={{
          position: 'absolute',
          left: '-70px',
          top: '-90px',
          width: '140px',
          height: '180px',
          borderRadius: '50%',
          background: 'radial-gradient(ellipse 45% 55% at 50% 50%, rgba(255,220,80,0.55) 0%, rgba(255,180,40,0.25) 50%, transparent 80%)',
          animation: 'flicker 1.2s ease-in-out infinite alternate-reverse',
        }}
      />
      {/* Layer 3: Orange mid glow */}
      <div
        style={{
          position: 'absolute',
          left: '-180px',
          top: '-220px',
          width: '360px',
          height: '440px',
          borderRadius: '50%',
          background: 'radial-gradient(ellipse 40% 50% at 50% 48%, rgba(255,150,30,0.35) 0%, rgba(255,100,20,0.12) 55%, transparent 82%)',
          animation: 'breathe 2.5s ease-in-out infinite',
        }}
      />
      {/* Layer 4: Wide ambient glow reaching edges */}
      <div
        style={{
          position: 'absolute',
          left: '-350px',
          top: '-400px',
          width: '700px',
          height: '800px',
          borderRadius: '50%',
          background: 'radial-gradient(ellipse 42% 48% at 50% 45%, rgba(255,120,40,0.15) 0%, rgba(255,80,20,0.05) 45%, transparent 72%)',
          animation: 'breathe 4s ease-in-out infinite alternate',
        }}
      />
      {/* Layer 5: Very wide warm tint across the whole page */}
      <div
        style={{
          position: 'absolute',
          left: '-500px',
          top: '-550px',
          width: '1000px',
          height: '1100px',
          borderRadius: '50%',
          background: 'radial-gradient(ellipse 45% 50% at 50% 45%, rgba(255,100,30,0.06) 0%, transparent 65%)',
        }}
      />
      <style>{`
        @keyframes flicker {
          0% { transform: scale(1) translate(0, 0); opacity: 0.9; }
          33% { transform: scale(1.08) translate(-2px, -3px); opacity: 1; }
          66% { transform: scale(0.96) translate(1px, 1px); opacity: 0.88; }
          100% { transform: scale(1.04) translate(-1px, -2px); opacity: 0.95; }
        }
        @keyframes breathe {
          0%, 100% { transform: scale(1); opacity: 0.7; }
          50% { transform: scale(1.12); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
