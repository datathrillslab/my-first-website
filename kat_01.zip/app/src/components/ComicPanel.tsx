interface ComicPanelProps {
  src: string;
  alt: string;
  isLast?: boolean;
}

export default function ComicPanel({ src, alt, isLast = false }: ComicPanelProps) {
  return (
    <section
      className={`comic-panel relative w-full h-screen flex items-center justify-center overflow-hidden ${
        isLast ? 'z-20' : 'z-10'
      }`}
    >
      <div className="relative w-full h-full max-w-4xl mx-auto flex items-center justify-center p-6 md:p-10">
        <div
          className="relative max-w-full max-h-full bg-white"
          style={{
            boxShadow: isLast
              ? '0 0 60px rgba(0,0,0,0.8), 0 0 120px rgba(0,0,0,0.4)'
              : '0 0 40px rgba(0,0,0,0.6), 0 0 80px rgba(0,0,0,0.3)',
          }}
        >
          <img
            src={src}
            alt={alt}
            className="max-w-full max-h-[85vh] object-contain block"
          />
        </div>
      </div>
    </section>
  );
}
