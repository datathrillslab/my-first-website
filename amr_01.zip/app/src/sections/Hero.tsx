import { useEffect, useRef } from "react";

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            section.classList.remove("opacity-0", "translate-y-6");
            section.classList.add("opacity-100", "translate-y-0");
            observer.unobserve(section);
          }
        });
      },
      { threshold: 0.2 }
    );

    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="min-h-screen flex flex-col justify-center px-6 md:px-12 lg:px-24 pt-[72px] opacity-0 translate-y-6 transition-all duration-700 ease-[cubic-bezier(0.25,0.46,0.45,0.94)]"
    >
      <div className="max-w-[680px]">
        <h1
          className="text-[#FFD700] text-2xl md:text-3xl lg:text-[2.5rem] leading-[1.3] font-normal mb-8"
          style={{ fontFamily: '"DM Sans", sans-serif' }}
        >
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat.
        </h1>

        <a
          href="#fonts"
          className="inline-flex items-center gap-3 border border-[#FFD700] text-[#FFD700] rounded-full px-6 py-3 text-sm uppercase tracking-widest font-medium hover:bg-[#FFD700] hover:text-black transition-all duration-300 ease-[cubic-bezier(0.25,0.46,0.45,0.94)]"
        >
          <span>Get Test Fonts</span>
          <svg
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="none"
            className="transition-transform duration-300 group-hover:translate-x-1"
          >
            <path
              d="M3 8H13M13 8L9 4M13 8L9 12"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </a>
      </div>
    </section>
  );
}
