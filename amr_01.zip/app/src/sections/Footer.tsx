export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="px-6 md:px-12 lg:px-24 py-12 md:py-16 border-t border-[#222222]">
      <div className="max-w-[1440px] mx-auto flex flex-col md:flex-row justify-between items-start gap-12">
        {/* Left */}
        <div className="flex flex-col gap-6">
          <span
            className="text-[#FFD700] text-2xl font-bold"
            style={{ fontFamily: '"DM Sans", sans-serif' }}
          >
            A
          </span>

          <div className="flex flex-col gap-2">
            <span className="text-[#8B7355] text-xs uppercase tracking-wider">
              Hotline
            </span>
            <a
              href="mailto:hello@foundry.co"
              className="text-[#FFD700] text-sm hover:text-[#FFF8DC] transition-colors duration-300"
            >
              hello@foundry.co
            </a>
            <span className="text-[#FFD700] text-sm">
              +1 (555) 000-0000
            </span>
          </div>

          <div className="flex gap-4">
            {["Twitter", "Facebook", "Instagram"].map((social) => (
              <a
                key={social}
                href="#"
                className="text-[#8B7355] text-sm hover:text-[#FFD700] transition-colors duration-300"
              >
                {social}
              </a>
            ))}
          </div>
        </div>

        {/* Right */}
        <div className="flex flex-col items-start md:items-end gap-4">
          <span className="text-[#8B7355] text-xs">
            &copy; 2026 Foundry
          </span>
          <a
            href="#"
            className="text-[#8B7355] text-xs hover:text-[#FFD700] transition-colors duration-300"
          >
            Support
          </a>
          <button
            onClick={scrollToTop}
            className="text-[#FFD700] text-sm hover:text-[#FFF8DC] transition-colors duration-300 flex items-center gap-2"
          >
            Back to top
            <span className="text-lg">&uarr;</span>
          </button>
        </div>
      </div>
    </footer>
  );
}
