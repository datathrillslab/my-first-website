import { useEffect, useRef } from "react";

interface FontCard {
  name: string;
  styles: number;
  price: string;
  preview: string;
  fontFamily: string;
  image?: string;
  featured?: boolean;
}

const FONTS: FontCard[] = [
  {
    name: "Dolor Sit",
    styles: 20,
    price: "€70.00",
    preview: "Lorem",
    fontFamily: "Playfair Display",
    image: "/images/font-preview-1.jpg",
  },
  {
    name: "Amet Consect",
    styles: 21,
    price: "€70.00",
    preview: "IPSUM",
    fontFamily: "Space Grotesk",
    image: "/images/font-preview-2.jpg",
  },
  {
    name: "Adipiscing Elit",
    styles: 24,
    price: "€70.00",
    preview: "DOLOR",
    fontFamily: "Oswald",
    featured: true,
  },
  {
    name: "Sed Do Eiusmod",
    styles: 12,
    price: "€70.00",
    preview: "SIT",
    fontFamily: "JetBrains Mono",
    image: "/images/font-preview-3.jpg",
  },
  {
    name: "Tempor Incid",
    styles: 12,
    price: "€70.00",
    preview: "AMET",
    fontFamily: "Cormorant Garamond",
  },
  {
    name: "Ut Labore Magna",
    styles: 3,
    price: "€70.00",
    preview: "CONSECT",
    fontFamily: "Syne",
  },
];

function FontCardItem({
  font,
  index,
}: {
  font: FontCard;
  index: number;
}) {
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const card = cardRef.current;
    if (!card) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            card.classList.remove("opacity-0", "translate-y-8");
            card.classList.add("opacity-100", "translate-y-0");
            observer.unobserve(card);
          }
        });
      },
      { threshold: 0.15 }
    );

    observer.observe(card);
    return () => observer.disconnect();
  }, []);

  const delay = index * 0.1;

  return (
    <div
      ref={cardRef}
      className={`group cursor-pointer opacity-0 translate-y-8 transition-all duration-700 ease-[cubic-bezier(0.25,0.46,0.45,0.94)] ${
        font.featured ? "md:col-span-2" : ""
      }`}
      style={{ transitionDelay: `${delay}s` }}
    >
      <div className="relative bg-[#111111] border border-[#222222] overflow-hidden hover:border-[#FFD700]/40 transition-all duration-300 ease-[cubic-bezier(0.25,0.46,0.45,0.94)] hover:-translate-y-1">
        {/* Preview area */}
        <div
          className={`relative flex items-center justify-center bg-black overflow-hidden ${
            font.featured ? "h-[400px] md:h-[500px]" : "h-[320px] md:h-[400px]"
          }`}
        >
          {font.image ? (
            <img
              src={font.image}
              alt={font.name}
              className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-500 ease-[cubic-bezier(0.25,0.46,0.45,0.94)]"
            />
          ) : (
            <span
              className="text-[#FFD700] text-[clamp(60px,10vw,140px)] leading-none select-none group-hover:scale-105 transition-transform duration-500 ease-[cubic-bezier(0.25,0.46,0.45,0.94)]"
              style={{ fontFamily: `"${font.fontFamily}", serif`, fontWeight: 700 }}
            >
              {font.preview}
            </span>
          )}
        </div>

        {/* Card info */}
        <div className="p-5 flex items-center justify-between">
          <div>
            <h3 className="text-[#FFD700] text-base font-medium mb-1">
              {font.name}
            </h3>
            <p className="text-[#8B7355] text-xs uppercase tracking-wider">
              {font.styles} Styles
            </p>
          </div>
          <span className="text-[#FFD700] text-sm font-medium">
            Starting at {font.price}
          </span>
        </div>
      </div>
    </div>
  );
}

export default function FontGrid() {
  return (
    <section id="fonts" className="px-6 md:px-12 lg:px-24 py-16 md:py-24">
      {/* Section header with marquee */}
      <div className="mb-12 overflow-hidden">
        <div className="flex animate-marquee whitespace-nowrap">
          {Array.from({ length: 8 }).map((_, i) => (
            <span
              key={i}
              className="text-[#FFD700]/20 text-sm uppercase tracking-[0.3em] mx-8 font-medium"
            >
              Download Test Fonts
            </span>
          ))}
        </div>
      </div>

      {/* Asymmetric grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-[1440px] mx-auto">
        {FONTS.map((font, index) => (
          <FontCardItem key={font.name} font={font} index={index} />
        ))}
      </div>
    </section>
  );
}
