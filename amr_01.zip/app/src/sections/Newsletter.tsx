import { useState } from "react";

export default function Newsletter() {
  const [email, setEmail] = useState("");

  return (
    <section className="px-6 md:px-12 lg:px-24 py-16 md:py-24">
      <div className="max-w-[480px]">
        <h2 className="text-[#FFD700] text-xl md:text-2xl font-medium mb-8 leading-snug">
          Subscribe to
          <br />
          Foundry Letters
        </h2>

        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            className="flex-1 bg-transparent border border-[#222222] text-[#FFD700] px-4 py-3 text-sm placeholder:text-[#8B7355] focus:border-[#FFD700] focus:outline-none transition-colors duration-300 rounded-none"
          />
          <button className="bg-[#FFD700] text-black px-6 py-3 text-sm uppercase tracking-wider font-medium hover:bg-[#FFF8DC] transition-colors duration-300 ease-[cubic-bezier(0.25,0.46,0.45,0.94)]">
            Subscribe
          </button>
        </div>
      </div>
    </section>
  );
}
