import { useState, useEffect, useRef, useCallback } from "react";

const FONTS = [
  "Playfair Display",
  "Inter",
  "Space Grotesk",
  "Cormorant Garamond",
  "JetBrains Mono",
  "Oswald",
  "Crimson Text",
  "Syne",
  "Libre Baskerville",
  "DM Sans",
];

// Deceleration schedule: [interval_ms, iterations]
const SCHEDULE: [number, number][] = [
  [80, 18],
  [150, 10],
  [300, 5],
  [500, 2],
];

interface IntroAnimationProps {
  onComplete: () => void;
}

export default function IntroAnimation({ onComplete }: IntroAnimationProps) {
  const [currentFontIndex, setCurrentFontIndex] = useState(0);
  const [phase, setPhase] = useState<"cycling" | "holding" | "exiting">("cycling");
  const scheduleIndex = useRef(0);
  const iterationCount = useRef(0);
  const lastTime = useRef(0);
  const rafId = useRef(0);
  const startTime = useRef(0);

  const nextSchedule = useCallback(() => {
    if (scheduleIndex.current >= SCHEDULE.length) {
      setPhase("holding");
      // Hold for 1.5s then exit
      setTimeout(() => {
        setPhase("exiting");
        setTimeout(() => {
          onComplete();
        }, 800);
      }, 1500);
      return;
    }

    const [interval, iterations] = SCHEDULE[scheduleIndex.current];
    iterationCount.current = 0;

    const tick = (timestamp: number) => {
      if (!startTime.current) startTime.current = timestamp;

      if (timestamp - lastTime.current >= interval) {
        lastTime.current = timestamp;
        iterationCount.current++;
        setCurrentFontIndex((prev) => (prev + 1) % FONTS.length);

        if (iterationCount.current >= iterations) {
          scheduleIndex.current++;
          nextSchedule();
          return;
        }
      }

      rafId.current = requestAnimationFrame(tick);
    };

    lastTime.current = 0;
    rafId.current = requestAnimationFrame(tick);
  }, [onComplete]);

  useEffect(() => {
    startTime.current = 0;
    scheduleIndex.current = 0;
    nextSchedule();

    return () => {
      if (rafId.current) cancelAnimationFrame(rafId.current);
    };
  }, [nextSchedule]);

  return (
    <div
      className={`fixed inset-0 z-[100] bg-black flex items-center justify-center transition-opacity duration-700 ${
        phase === "exiting" ? "opacity-0 pointer-events-none" : "opacity-100"
      }`}
    >
      <div
        className={`transition-all duration-700 ease-[cubic-bezier(0.87,0,0.13,1)] ${
          phase === "exiting"
            ? "translate-x-[-50vw] translate-y-[-45vh] scale-[0.12]"
            : "translate-x-0 translate-y-0 scale-100"
        }`}
      >
        <span
          className="text-[#FFD700] leading-none select-none block"
          style={{
            fontFamily: `"${FONTS[currentFontIndex]}", serif`,
            fontSize: "clamp(200px, 25vw, 400px)",
            fontWeight: 700,
            transition: "font-family 0.05s ease",
          }}
        >
          A
        </span>
      </div>
    </div>
  );
}
