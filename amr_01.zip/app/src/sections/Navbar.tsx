import { useState, useEffect } from "react";

const NAV_LINKS = ["Fonts", "WIP", "Test Fonts", "Projects", "About"];

export default function Navbar() {
  const [isSticky, setIsSticky] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsSticky(window.scrollY > window.innerHeight * 0.5);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 h-[72px] flex items-center justify-between px-6 md:px-12 transition-all duration-500 ${
        isSticky
          ? "bg-black/90 backdrop-blur-sm border-b border-[#222222]"
          : "bg-transparent"
      }`}
    >
      <a
        href="#"
        className="text-[#FFD700] text-2xl font-bold"
        style={{ fontFamily: '"DM Sans", sans-serif' }}
      >
        A
      </a>

      <div className="hidden md:flex items-center gap-8">
        {NAV_LINKS.map((link) => (
          <a
            key={link}
            href="#"
            className="relative text-[#FFD700] text-sm uppercase tracking-widest font-medium group"
          >
            {link}
            <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-[#FFD700] transition-all duration-300 ease-[cubic-bezier(0.25,0.46,0.45,0.94)] group-hover:w-full" />
          </a>
        ))}
      </div>

      <button className="md:hidden text-[#FFD700] text-sm uppercase tracking-widest font-medium">
        Menu
      </button>
    </nav>
  );
}
