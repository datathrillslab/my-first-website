const CATEGORIES = [
  "Display",
  "Text",
  "Sans Serif",
  "Serif",
  "Mono",
  "Script",
];

export default function Categories() {
  return (
    <section className="px-6 md:px-12 lg:px-24 py-12 md:py-16">
      <h2 className="text-[#8B7355] text-xs uppercase tracking-[0.2em] font-medium mb-8">
        Browse by Category
      </h2>
      <div className="flex flex-wrap gap-3">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            className="border border-[#222222] text-[#FFD700] rounded-full px-5 py-2.5 text-sm font-medium hover:border-[#FFD700] hover:bg-[#FFD700]/5 transition-all duration-300 ease-[cubic-bezier(0.25,0.46,0.45,0.94)]"
          >
            {cat}
          </button>
        ))}
      </div>
    </section>
  );
}
