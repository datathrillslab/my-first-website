import { useState, useCallback } from "react";
import IntroAnimation from "./sections/IntroAnimation";
import Navbar from "./sections/Navbar";
import Hero from "./sections/Hero";
import FontGrid from "./sections/FontGrid";
import Categories from "./sections/Categories";
import Newsletter from "./sections/Newsletter";
import Footer from "./sections/Footer";

export default function App() {
  const [introComplete, setIntroComplete] = useState(false);

  const handleIntroComplete = useCallback(() => {
    setIntroComplete(true);
  }, []);

  return (
    <div className="min-h-screen bg-black">
      {!introComplete && <IntroAnimation onComplete={handleIntroComplete} />}

      <Navbar />

      <main>
        <Hero />
        <FontGrid />
        <Categories />
        <Newsletter />
      </main>

      <Footer />
    </div>
  );
}
